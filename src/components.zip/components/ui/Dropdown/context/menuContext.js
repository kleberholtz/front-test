  
import React from 'react'

const MenuContext = React.createContext(null)

export const MenuContextProvider = MenuContext.Provider

export default MenuContext