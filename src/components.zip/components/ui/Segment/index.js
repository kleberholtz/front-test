import Segment from './Segment'
import SegmentItem from './SegmentItem'

Segment.Item = SegmentItem

export default Segment